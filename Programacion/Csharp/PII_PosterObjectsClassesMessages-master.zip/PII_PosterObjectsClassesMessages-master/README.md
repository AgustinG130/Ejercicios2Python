# Universidad Católica del Uruguay
## Facultad de Ingeniería y Tecnologías
### Programación II

Agrega la clase Person encapsulada y modifícala para que sólo acepte nombres y cédulas válidas. El nombre es válido si no está en blanco. La cédula es válida si es correcto el dígito verificador.

Usen el código provisto en el adjunto como punto de partida. El código incluye líneas que crean personas con información válida y el código para verificar si una cédula es válida calculando el dígito verificador.

No incluye el código de la clase Person, que deberán programar ustedes a partir del [ejercicio](https://github.com/ucudal/PII_Identificar_partes_de_objeto) de identificar las partes de un objeto.

## Entrega

Armen un .ZIP con todos los archivos de proyecto y entreguen el .ZIP en webasignatura
