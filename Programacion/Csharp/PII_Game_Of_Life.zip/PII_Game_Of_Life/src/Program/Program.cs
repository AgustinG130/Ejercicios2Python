﻿using System;
using System.IO;
using System.Text;
using System.Threading;

namespace Ucu.Poo.GameOfLife
{
    public class Program
    {
        static void Main(string[] args)
        {   
            CreadorTablero creador = new CreadorTablero(@"C:\Users\agust\Programacion\Csharp\PII_Game_Of_Life\assets\board.txt");
            Tablero tb1 = new Tablero();
            ImpresionTablero Impresion1 = new ImpresionTablero.Impresion();
            Impresion1();
            tb1(); //creo que no deberia imprimirse quizas se pasa por parametro en la impresion

        }
    }
}