using System;
using System.IO;
using System.Text;
using System.Threading;

namespace Ucu.Poo.GameOfLife
{
public class CreadorTablero
            {
            public bool[,] board {get; set;} //no estoy seguro si es correcto
            public CreadorTablero(string filePath)
            {
                string content = File.ReadAllText(@"C:\Users\agust\Programacion\Csharp\PII_Game_Of_Life\assets\board.txt");
                string[] contentLines = content.Split('\n');
                bool[,] board = new bool[contentLines.Length, contentLines[0].Length];

                for (int y=0; y < contentLines.Length; y++)
                {
                    for (int x=0; x < contentLines[y].Length; x++)
                    {
                        if(contentLines[y][x] == '1')
                        {
                            board[x,y] = true;
                        }
                    }
                }
            }
        }
    }