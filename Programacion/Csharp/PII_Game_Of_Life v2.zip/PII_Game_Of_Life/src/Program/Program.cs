﻿using System;
using System.IO;
using System.Text;
using System.Threading;

namespace Ucu.Poo.GameOfLife
{
    public class Program
    {
        static void Main(string[] args)
        {

            Tablero tablero = new Tablero(10, 10); //creo un tablero porej 10x10 con estado inicial aleatorio

            ImpresionTablero Impresion1 = new ImpresionTablero(tablero.gameBoard); //instancio ImpresionTablero con el estado inicial

            Impresion1.Impresion(tablero.boardWidth, tablero.boardHeight); //llamo al metodo de impresion

            tablero.Algoritmo(); //llamo al metodo de algoritmo

        }            
    }
}