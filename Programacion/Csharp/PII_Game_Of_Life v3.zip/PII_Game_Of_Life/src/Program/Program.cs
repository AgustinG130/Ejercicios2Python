﻿using System;
using System.IO;
using System.Text;
using System.Threading;

namespace Ucu.Poo.GameOfLife
{
    public class Program
    {
        static void Main(string[] args)
        {
            int Juego; //declaro la variable de tipo entero llamado Juego
            Tablero tablero = new Tablero(10, 10); //creo un tablero por ej 10x10 con estado inicial aleatorio
            Console.WriteLine("Elija como iniciar el Game Of Life: \n 1- Nuevo \n 2- Por Archivo");
            string JuegoNumero = Console.ReadLine(); //creo la variable JuegoNumero y la utilizo de input
            Juego = Convert.ToInt32(JuegoNumero); //convierto a entero la variable JuegoNumero

            if (Juego == 2) //hago un if para saber si debo leer el archivo txt o no
            {
                CreadorTablero creadortablero1 = new CreadorTablero(@"C:\Users\agust\Programacion\Csharp\PII_Game_Of_Life\assets\board.txt"); //instancio el creadortablero con el board.txt
                tablero = new Tablero(creadortablero1.board); //instancio un tablero dando por parametro el creadortablero
            }

            //no es necesario un else en mi opinion ya que al comparar Juego con el 2 nos ahorramos los errores de que agregue otro numero

            ImpresionTablero Impresion1 = new ImpresionTablero(tablero.gameBoard); //instancio ImpresionTablero con el estado inicial

            Impresion1.Impresion(tablero.boardWidth, tablero.boardHeight); //llamo al metodo de impresion

            tablero.Algoritmo(); //llamo al metodo de algoritmo

        }            
    }
}