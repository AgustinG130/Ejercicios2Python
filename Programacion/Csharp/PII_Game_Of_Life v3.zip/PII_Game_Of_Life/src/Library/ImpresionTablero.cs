using System;
using System.IO;
using System.Text;
using System.Threading;

namespace Ucu.Poo.GameOfLife
{

public class ImpresionTablero {     

                private bool[,] gameBoard;      
                public ImpresionTablero(bool[,] gameBoard) 
                {
                    this.gameBoard = gameBoard;
                }
                public void Impresion(int width, int height)
                {
                    while (true)
                    {
                        Console.Clear();
                        StringBuilder s = new StringBuilder();
                        for (int y = 0; y<height;y++)
                        {
                            for (int x = 0; x<width; x++)
                            {
                                if(gameBoard[x,y])
                                {
                                    s.Append("|X|");
                                }
                                else
                                {
                                    s.Append("___");
                                }
                            }
                            s.Append("\n");
                        }
                        Console.WriteLine(s.ToString());
                        //=================================================
                        //Invocar método para calcular siguiente generación
                        //=================================================
                        Thread.Sleep(300);
                    }
                }
            }
        }