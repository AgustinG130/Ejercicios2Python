using System;
using System.IO;
using System.Text;
using System.Threading;

namespace Ucu.Poo.GameOfLife
{
public class Tablero {
    public bool[,] gameBoard;
    public int boardWidth;
    public int boardHeight;
    public Tablero(bool[,] gameBoard)
    {   
        this.gameBoard = gameBoard;
        this.boardWidth = gameBoard.GetLength(0);
        this.boardHeight = gameBoard.GetLength(1);
    }

    public Tablero(int width, int height)
    {   
        Random random = new Random();
        this.boardWidth = width;
        this.boardHeight = height;
        this.gameBoard = new bool[boardWidth, boardHeight];

        for (int x = 0; x < boardWidth; x++)
        {
            for (int y = 0; y < boardHeight; y++)
            {
                this.gameBoard[x, y] = random.Next(2) == 0; //50% de posibilidad de estar vivo
            }
        }
            }
            public void Algoritmo() 
            {
                bool[,] cloneboard = new bool[boardWidth, boardHeight];
                for (int x = 0; x < boardWidth; x++)
                {
                for (int y = 0; y < boardHeight; y++)
                {
                    int aliveNeighbors = 0;
                    for (int i = x-1; i<=x+1;i++)
                    {
                        for (int j = y-1;j<=y+1;j++)
                        {
                            if(i>=0 && i<boardWidth && j>=0 && j < boardHeight && gameBoard[i,j])
                            {
                                aliveNeighbors++;
                            }
                        }
                    }
                    if(gameBoard[x,y])
                    {
                        aliveNeighbors--;
                    }
                    if (gameBoard[x,y] && aliveNeighbors < 2)
                    {
                        //Celula muere por baja población
                        cloneboard[x,y] = false;
                    }
                    else if (gameBoard[x,y] && aliveNeighbors > 3)
                    {
                        //Celula muere por sobrepoblación
                        cloneboard[x,y] = false;
                    }
                    else if (!gameBoard[x,y] && aliveNeighbors == 3)
                    {
                        //Celula nace por reproducción
                        cloneboard[x,y] = true;
                    }
                    else
                    {
                        //Celula mantiene el estado que tenía
                        cloneboard[x,y] = gameBoard[x,y];
                    }
                }
            }
            gameBoard = cloneboard;
            }
        }
    }