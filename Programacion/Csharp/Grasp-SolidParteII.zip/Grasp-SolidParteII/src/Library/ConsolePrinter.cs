using System;
using System.Collections;
namespace Full_GRASP_And_SOLID.Library
{
    //Como hemos dicho en clase es necesario una clase printer ya que
    //si quiero cambiar la forma de imprimir tengo que cambiar todo el 
    //codigo en lugar de este metodo como se me pidió teniendo en cuenta el SRP, Solid y GRASP.

    public class ConsolePrinter 
        {   
        public void CPrinter(Recipe recipe)
        {
            Console.WriteLine($"Receta de {recipe.FinalProduct.Description}:");
            foreach (Step step in recipe.steps)
            {
                Console.WriteLine($"{step.Quantity} de '{step.Input.Description}' " +
                    $"usando '{step.Equipment.Description}' durante {step.Time}");
            }
        }
    }
}