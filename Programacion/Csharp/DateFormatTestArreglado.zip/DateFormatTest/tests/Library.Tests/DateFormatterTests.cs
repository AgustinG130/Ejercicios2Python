namespace Library.Tests;
using TestDateFormat;
public class DataFormatterTests
{
    [SetUp]
    public void Setup()
    {
    }

    [Test]
    public void DataFormatTestReal()
    {

        const string realdate = "04-05-2020";
        string dateExpected = "2020-05-04";
        string dateformat = DateFormatter.ChangeFormat(realdate);
        Assert.AreEqual(dateExpected,dateformat);

    }

    [Test]
    public void DateFormatTestNoDate()
    {
        const string nodate = "";
        string dateExpected = "Fecha invalida";
        string dateformat = DateFormatter.ChangeFormat(nodate);
        Assert.AreEqual(dateExpected,dateformat);
    }

    [Test]
    public void DataFormatTestFake()
    {
        const string fakedate = "31,22,2020";
        string dateExpected = "Fecha invalida";
        string dateformat = DateFormatter.ChangeFormat(fakedate);
        Assert.AreEqual(dateExpected, dateformat);
    }

     [Test]
    public void DataFormatTestLenght()
    {
        string datelong = "301,202,2020";
        string dateExpected = "Fecha invalida";
        string dateformat = DateFormatter.ChangeFormat(datelong);
        Assert.AreEqual(dateExpected, dateformat);
        //////////////////////////////////////
        datelong = "1,2,20";
        dateExpected = "Fecha invalida";
        dateformat = DateFormatter.ChangeFormat(datelong);
        Assert.AreEqual(dateExpected, dateformat);
    }
}